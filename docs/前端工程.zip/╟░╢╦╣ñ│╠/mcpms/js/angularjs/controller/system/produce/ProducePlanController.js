app.controller('ProducePlanController',function ($scope,ProducePlanService) {

    /**
     * 生产计划管理模块
     */


    /**
     * 日期控件
     */
    layui.use(['laydate'],function () {
        var laydate = layui.laydate
        //签订时间
        laydate.render({
            elem: '#planFinshTime'
            ,isInitValue: false
            ,format: 'yyyy-MM-dd'
            ,value: '2019-01-01'
            ,ready: function(date){
                console.log(date);
            }
            ,done: function(value, date, endDate){
                console.log(value, date, endDate);
            }
        });

        var laydate = layui.laydate
        //签订时间
        laydate.render({
            elem: '#processPlanTime'
            ,isInitValue: false
            ,format: 'yyyy-MM-dd'
            ,value: '2019-01-01'
            ,ready: function(date){
                console.log(date);
            }
            ,done: function(value, date, endDate){
                console.log(value, date, endDate);
            }
        });
    })


    /**
     * 产品基础数据
     * @type {Array}
     */
    $scope.searchProductData = []

    /**
     * 零件基础数据
     * @type {Array}
     */
    $scope.searchPartsData = []

    /**
     * 条件查询对象
     * @type {{}}
     */
    $scope.search = {}


    /**
     * 当前查看的生产计划对象
     * @type {{}}
     */
    $scope.currentPlan = {}


    /**
     * 生产计划对象
     * @type {{}}
     */
    $scope.plan = {}


    /**
     * 生产计划-工序对象
     * @type {{}}
     */
    $scope.process = {}


    /**
     * 初始化数据
     */
    $scope.initData = function(){
        ProducePlanService.initData().success((response)=>{
            if (response.code == 200){
                $scope.searchProductData = response.data.productData
                $scope.searchPartsData = response.data.partsData
                $scope.modeData = response.data.modeData
                $scope.outData = response.data.outData
            } else{
                requestError(response.msg)
            }
        }).error((e)=>{systemError()})
    }


    /**
     * 生产计划分页控件配置
     * @type {{currentPage: number, totalItems: number, itemsPerPage: number, perPageOptions: number[], onChange: onChange}}
     */
    $scope.producePlanPagination = {
        currentPage: 1,
        totalItems: 25,
        itemsPerPage: 10,
        perPageOptions: [10, 20, 30, 40],
        onChange: function(){
            $scope.reloadProducePlanList();//重新加载
        }
    }

    /**
     * 刷新生产计划列表
     */
    $scope.reloadProducePlanList = function () {
        $scope.getAllProducePlan($scope.producePlanPagination.currentPage,$scope.producePlanPagination.itemsPerPage)
    }

    /**
     * 分页条件获取所有生产计划列表
     * @param page
     * @param size
     */
    $scope.getAllProducePlan = function (page, size) {
        ProducePlanService.getAllPlan(page,size,$scope.search).success((response)=>{
            if (response.code == 200){
                $scope.producePlanPagination.totalItems = response.data.total
                $scope.producePlanList = response.data.data
            } else{
                requestError(response.msg)
            }
        }).error((e)=>{systemError()})
    }


    /**
     * 根据id查找生产计划对象
     * @param id
     */
    $scope.findone = function(id){
        ProducePlanService.findone(id).success((response)=>{
            if (response.code == 200){
                $scope.plan = response.data
                $('#planFinshTime').val($scope.plan.planTime)
            } else{
                requestError(response.msg)
            }
        }).error((e)=>{systemError()})
    }


    /**
     * 保存生产计划编辑
     */
    $scope.save = function(){
        $scope.plan.planTime = $('#planFinshTime').val()
        ProducePlanService.save($scope.plan).success((response)=>{
            if (response.code == 200){
                updateSuccess()
            } else{
                requestError(response.msg)
            }
        }).error((e)=>{systemError()})
    }

    /**
     * 更新当前查看的生产计划对象
     * @param entity
     */
    $scope.updateCurrentPlan = function(entity){
        $scope.currentPlan = entity
        $scope.getAllProcessByPlanId()
    }

    $scope.getAllProcessByPlanId = function(){
        ProducePlanService.getAllProcessByPlanId($scope.currentPlan.id).success((response)=>{
            if (response.code == 200){
                $scope.processList = response.data
            } else{
                requestError(response.msg)
            }
        }).error((e)=>{systemError()})
    }


    /**
     * 生产计划 - 工序模块
     * @type {*[]}
     */


    /**
     * 打开生产计划-工序修改模态窗
     * @param id
     */
    $scope.openProcessModal = function(id){
        ProducePlanService.findoneProcess(id).success((response)=>{
            if (response.code == 200){
                $scope.process = response.data
                $('#processPlanTime').val($scope.process.planTime)

            } else{
                requestError(response.msg)
            }
        }).error((e)=>{systemError()})
        $('#editNum').modal()
    }

    /**
     * 保存工序编辑
     */
    $scope.saveProcess = function(){

        $scope.process.planTime = $('#processPlanTime').val()

        ProducePlanService.saveProcess($scope.process).success((response)=>{
            if (response.code == 200){
                $scope.getAllProcessByPlanId()
                updateSuccess()
            } else{
                requestError(response.msg)
            }
        }).error((e)=>{systemError()})
    }


    $scope.producePlanList = [
        {
            "id":1,
            "orderNum":"GKKAS112",
            "produceName":"超纤机",
            "runningNum":"212312",
            "drawingNum":"asdasd",
            "partName":"握把",
            "num":2,
            "unit":"件",
            "isInsert":"否",
            "planTime":"2019-02-18",
            "actualTime":"2019-02-18",
            "inTime":"2019-02-18",
            "approveStatusStr":"未审",
            "statusStr":"待审"
        },
        {
            "id":1,
            "orderNum":"GKKAS112",
            "produceName":"超纤机",
            "runningNum":"212312",
            "drawingNum":"asdasd",
            "partName":"握把",
            "num":2,
            "unit":"件",
            "isInsert":"否",
            "planTime":"2019-02-18",
            "actualTime":"2019-02-18",
            "inTime":"2019-02-18",
            "approveStatusStr":"已审",
            "statusStr":"执行"
        },
        {
            "id":1,
            "orderNum":"GKKAS112",
            "produceName":"超纤机",
            "runningNum":"212312",
            "drawingNum":"asdasd",
            "partName":"握把",
            "num":2,
            "unit":"件",
            "isInsert":"否",
            "planTime":"2019-02-18",
            "actualTime":"2019-02-18",
            "inTime":"2019-02-18",
            "approveStatusStr":"已审",
            "statusStr":"执行"
        },
        {
            "id":1,
            "orderNum":"GKKAS112",
            "produceName":"超纤机",
            "runningNum":"212312",
            "drawingNum":"asdasd",
            "partName":"握把",
            "num":2,
            "unit":"件",
            "isInsert":"否",
            "planTime":"2019-02-18",
            "actualTime":"2019-02-18",
            "inTime":"2019-02-18",
            "approveStatusStr":"已审",
            "statusStr":"执行"
        },
        {
            "id":1,
            "orderNum":"GKKAS112",
            "produceName":"超纤机",
            "runningNum":"212312",
            "drawingNum":"asdasd",
            "partName":"握把",
            "num":2,
            "unit":"件",
            "isInsert":"否",
            "planTime":"2019-02-18",
            "actualTime":"2019-02-18",
            "inTime":"2019-02-18",
            "approveStatusStr":"已审",
            "statusStr":"已入库"
        },
        {
            "id":1,
            "orderNum":"GKKAS112",
            "produceName":"超纤机",
            "runningNum":"212312",
            "drawingNum":"asdasd",
            "partName":"握把",
            "num":2,
            "unit":"件",
            "isInsert":"否",
            "planTime":"2019-02-18",
            "actualTime":"2019-02-18",
            "inTime":"2019-02-18",
            "approveStatusStr":"驳回",
            "statusStr":"待审"
        },
    ]

    $scope.processList = [
        {
            "sort":1,
            "processName":"外协1",
            "modeName":"外协加工",
            "outName":"云彩",
            "drawingNum":"GJSAJ22",
            "outTime":"2019-02-19",
            "planTime":"2019-02-22",
            "day":"3",
            "inTime":"2019-02-21",
            "actualTime":"2019-02-21",
            "remarks":"",
            "approvesStatus":"已审",
            "status":"完成"
        },
        {
            "sort":1,
            "processName":"外协1",
            "modeName":"外协加工",
            "outName":"云彩",
            "drawingNum":"GJSAJ22",
            "outTime":"2019-02-19",
            "planTime":"2019-02-22",
            "day":"3",
            "inTime":"",
            "actualTime":"",
            "remarks":"",
            "approvesStatus":"已审",
            "status":"执行"
        },
        {
            "sort":1,
            "processName":"外协1",
            "modeName":"外协加工",
            "outName":"云彩",
            "drawingNum":"GJSAJ22",
            "outTime":"2019-02-19",
            "planTime":"2019-02-22",
            "day":"3",
            "inTime":"",
            "actualTime":"",
            "remarks":"",
            "approvesStatus":"未审",
            "status":"待审"
        },
        {
            "sort":1,
            "processName":"外协1",
            "modeName":"外协加工",
            "outName":"云彩",
            "drawingNum":"GJSAJ22",
            "outTime":"2019-02-19",
            "planTime":"2019-02-22",
            "day":"3",
            "inTime":"",
            "actualTime":"",
            "remarks":"",
            "approvesStatus":"未审",
            "status":"待审"
        }
    ]

})