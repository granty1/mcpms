app.controller('BasePartsController',function ($scope,BasePartsService) {


    /**
     * 初始化layui form
     */
    layui.use(['form','jquery'],function () {
        var form = layui.form;
        var $ = layui.jquery;

        form.on('select(method)',function (data) {
            if(data.value == "自下料外协加工" || data.value == "外协加工"){
                $('#outCompanyDiv').removeAttr("hidden");
                if($scope.clickId != null){
                    primaryMessage('请选择一个外协单位')
                }
            }else{
                $('#outCompanyDiv').attr("hidden",true);
            }
            form.render('select');
        })

        form.render('select');
    })

    $scope.initData = function(){
        BasePartsService.initDataList().success((response)=>{
            if (response.code == 200){
                $scope.processMethodList = response.data.methodList
                $scope.outSourceList = response.data.outList
                $scope.processDataList = response.data.processList
            } else{
                requestError(response.msg)
            }
        }).error((e)=>{systemError()})
    }



    /**
     * 零件模块
     * @author guolin
     */


    /**
     * 查询条件对象
     * @type {{}}
     */
    $scope.search = {};


    /**
     * 零件管理 分页
     * @type {{currentPage: number, totalItems: number, itemsPerPage: number, perPageOptions: number[], onChange: onChange}}
     */
    $scope.partsPaginationConf = {
        currentPage: 1,
        totalItems: 22,
        itemsPerPage: 10,
        perPageOptions: [10, 20, 30, 40],
        onChange: function(){
            $scope.reloadPartsList();//重新加载
        }
    };

    /**
     * 重载零件数据列表
     */
    $scope.reloadPartsList = function(){
        $scope.getAllParts($scope.partsPaginationConf.currentPage,$scope.partsPaginationConf.itemsPerPage);
    }

    /**
     * 分页获取所有零件列表
     * @param page 当前页
     * @param size 页的大小
     */
    $scope.getAllParts = function(page,size){
        BasePartsService.getAll(page,size,$scope.search).success((response)=>{
            if (response.code == 200){
                $scope.partsList = response.data.data
                $scope.partsPaginationConf.totalItems = response.total
            } else{
                requestError(response.msg)
            }
        }).error((e)=>{systemError()})
    }


    /**
     * 选中零件id集合
     * @type {Array}
     */
    $scope.partsSelectIds=[];//选中的ID集合
    //更新复选
    $scope.updatePartsSelection = function($event, id) {
        if($event.target.checked){//如果是被选中,则增加到数组
            $scope.partsSelectIds.push( id);
        }else{
            var idx = $scope.partsSelectIds.indexOf(id);
            $scope.partsSelectIds.splice(idx, 1);//删除
        }
    }

    /**
     * 单个零件实体
     * @type {{}}
     */
    $scope.parts = {};

    /**
     * 当前工序编辑零件名称
     * @type {*[]}
     */
    $scope.currentParts = {};

    /**
     * 更新当前编辑的零件对象
     * 查找当前零件的所有工序
     * @param parts
     */
    $scope.updateCurrentParts = function(parts){
        $scope.currentParts = parts
        
        $scope.getAllProcess($scope.currentParts.id)
    }


    /**
     * 根据id获取所有工序
     * @param id 零件id
     */
    $scope.getAllProcess = function(id){
        BasePartsService.getAllProcess(id).success((response)=>{
            if (response.code == 200){
                $scope.processList = response.data.data
            } else{
                requestError(response.msg)
            }
        }).error((e)=>{systemError()})
    }

    $scope.findone = function(id){
        BasePartsService.findone(id).success((response)=>{
            if (response.code == 200){
                $scope.parts = response.data
            } else{
                requestError(response.msg)
            }
        }).error((e)=>{systemError()})
    }

    /**
     * 保存零件编辑
     */
    $scope.partsSave = function(){
        if($scope.parts.id==null){
            //新增
            BasePartsService.add($scope.parts).success((response)=>{
                if (response.code == 200){
                    $scope.reloadPartsList()
                    saveSuccess()
                } else{
                    requestError(response.msg)
                }
            }).error((e)=>{systemError()})
        }else {
            //修改
            BasePartsService.update($scope.parts).success((response)=>{
                if (response.code == 200){
                    $scope.reloadPartsList()
                    saveSuccess()
                } else{
                    requestError(response.msg)
                }
            }).error((e)=>{systemError()})
        }
    }

    /**
     * 根据id删除
     * @param id
     */
    $scope.delete = function(id){
        layer.confirm('您确定要删除吗？', {
            btn: ['确定','取消'] //按钮
        }, function(){
            $scope.ids = []
            $scope.ids.push(id)
            deleteBase($scope.ids)
            $scope.ids = []
        })

    }

    /**
     * 批量删除
     */
    $scope.deleteBatch = function(){
        if($scope.partsSelectIds.length==0){
            primaryMessage('请选择')
        }else{
            layer.confirm('您确定要删除吗？', {
                btn: ['确定','取消'] //按钮
            }, function(){
                deleteBase($scope.partsSelectIds)
                $scope.partsSelectIds = []
            })
        }
    }

    /**
     * 删除公共方法
     * @param ids
     */
    var deleteBase = function(ids){
        BasePartsService.deleteBatch(ids).success((response)=>{
            if (response.code == 200){
                deleteSuccess()
                $scope.reloadPartsList()
            } else{
                requestError(response.msg)
            }
        }).error((e)=>{systemError()})
    }








    /**
     * 零件工序模块
     * @author guolin
     * @type {*[]}
     */


    /**
     * 工序实体
     * @type {{}}
     */
    $scope.process = {};


    /**
     * 修改的工序id
     * @type {null}
     */
    $scope.clickId = null

    /**
     * 工序编辑窗口
     * @type {*[]}
     */
    $scope.openProcessModal = function(id){
        if(id==null){
            //新增
        }else{
            //修改
            $scope.clickId = id
            $scope.findoneProcess(id)
            //初始化加工工序
            var select = 'dd[lay-value='+$scope.process.processId+']';
            $('#processProcess').siblings("div.layui-form-select").find('dl').find(select).click();
            //初始化加工方式
            var select = 'dd[lay-value='+$scope.process.way+']';
            $('#processMethod').siblings("div.layui-form-select").find('dl').find(select).click();
            if($scope.process.way == "自下料外协加工" || $scope.process.way == "外协加工"){
                $('#outCompanyDiv').removeAttr("hidden");
                //初始化外协单位
                var select = 'dd[lay-value='+$scope.process.outId+']';
                $('#outCompany').siblings("div.layui-form-select").find('dl').find(select).click();
            }
            layui.form.render('select')
        }

        $('#addProcessModal').modal();
    }

    /**
     * 根据零件-工序id查找零件-工序对象
     * @param id
     */
    $scope.findoneProcess = function(id){
        BasePartsService.findoneProcess(id).success((response)=>{
            if (response.code == 200){
                $scope.process = response.data
            } else{
                requestError(response.msg)
            }
        }).error((e)=>{systemError()})
        /*$scope.process = {
            "id":12312312,
            "processId":2,
            "way":3,
            "outId":3
        }*/
    }

    /**
     * 零件-工序 编辑 保存
     */
    $scope.processSave = function(){
        //自动选中
        /*var select = 'dd[lay-value='+2+']';
        $('#processMethod').siblings("div.layui-form-select").find('dl').find(select).click();*/

        //加工工序
        var processSelectedId = $('#processProcess').val();

        //加工方式
        var methodSelectedId = $('#processMethod').val();

        //外协单位
        var outCompanySelectedId = $('#outCompany').val();


        if(processSelectedId=="? undefined:undefined ?"){
            layer.msg('请选择加工工序',{icon:5})
        }else{
            if(methodSelectedId == "? undefined:undefined ?"){
                layer.msg('请选择加工方式',{icon:5})
            }else{
                $scope.process.processId = processSelectedId
                $scope.process.way = methodSelectedId
                console.log(methodSelectedId)
                if((methodSelectedId == "自下料外协加工" || methodSelectedId == "外协加工" )&& outCompanySelectedId == "? undefined:undefined ?"){
                    layer.msg('请选择一个外协单位',{icon:5})
                }else{
                    $scope.process.outId = outCompanySelectedId
                    if($scope.process.id==null){
                        $scope.process.partsId = $scope.currentParts.id
                        // 新增
                        BasePartsService.processSave($scope.process).success((response)=>{
                            if (response.code == 200){
                                $scope.getAllProcess($scope.currentParts.id)
                                saveSuccess()
                                $scope.process = {}
                                $('#outCompanyDiv').attr("hidden",true)
                            } else{
                                requestError(response.msg)
                            }
                        }).error((e)=>{systemError()})
                    }else{
                        //修改保存
                        BasePartsService.processUpdate($scope.process).success((response)=>{
                            if (response.code == 200){
                                $scope.getAllProcess($scope.currentParts.id)
                                updateSuccess()
                                $scope.process = {}
                                $('#outCompanyDiv').attr("hidden",true)
                            } else{
                                requestError(response.msg)
                            }
                        }).error((e)=>{systemError()})
                    }
                }

            }
        }
    }

    /**
     * 清空对象
     */
    $scope.clearProcess = function(){
        $scope.process = {}
        $('#outCompanyDiv').attr("hidden",true);
    }

    /**
     * 工序删除
     * @type {*[]}
     */
    $scope.processDelete = function(id){
        layer.confirm('您确定要删除吗？', {
            btn: ['确定','取消'] //按钮
        }, function(){
            BasePartsService.deleteProcess(id).success((response)=>{
                if (response.code == 200){
                    $scope.findoneProcess($scope.clickId)
                    deleteSuccess()
                } else{
                    requestError(response.msg)
                }
            }).error((e)=>{systemError()})
        })
    }







    $scope.partsList = [
        {
            "id":1,
            "partNum":201801,
            "name":"手动挡杆",
            "drawingNum":"GTSG3-160-0505",
            "unit":"件",
            "remarks":"2019新款"
        },
        {
            "id":1,
            "partNum":201801,
            "name":"手动挡杆",
            "drawingNum":"GTSG3-160-0505",
            "unit":"件",
            "remarks":"2019新款"
        },
        {
            "id":1,
            "partNum":201801,
            "name":"手动挡杆",
            "drawingNum":"GTSG3-160-0505",
            "unit":"件",
            "remarks":"2019新款"
        },
        {
            "id":1,
            "partNum":201801,
            "name":"手动挡杆",
            "drawingNum":"GTSG3-160-0505",
            "unit":"件",
            "remarks":"2019新款"
        },
        {
            "id":1,
            "partNum":201801,
            "name":"手动挡杆",
            "drawingNum":"GTSG3-160-0505",
            "unit":"件",
            "remarks":"2019新款"
        },
        {
            "id":1,
            "partNum":201801,
            "name":"手动挡杆",
            "drawingNum":"GTSG3-160-0505",
            "unit":"件",
            "remarks":"2019新款"
        }
    ]



    $scope.processList = [
        {
            "id":1,
            "processName":"火焰下料",
            "way":"外协",
            "outName":"云彩",
            "day":11,
            "drawingNum":"GDSG",
            "price":12.9,
            "remarkds":""
        },
        {
            "id":1,
            "processName":"火焰下料",
            "way":"外协",
            "outName":"云彩",
            "day":11,
            "drawingNum":"GDSG",
            "price":12.9,
            "remarkds":""
        },
        {
            "id":1,
            "processName":"火焰下料",
            "way":"外协",
            "outName":"云彩",
            "day":11,
            "drawingNum":"GDSG",
            "price":12.9,
            "remarkds":""
        },
        {
            "id":1,
            "processName":"火焰下料",
            "way":"外协",
            "outName":"云彩",
            "day":11,
            "drawingNum":"GDSG",
            "price":12.9,
            "remarkds":""
        },
        {
            "id":1,
            "processName":"火焰下料",
            "way":"外协",
            "outName":"云彩",
            "day":11,
            "drawingNum":"GDSG",
            "price":12.9,
            "remarkds":""
        }
    ]

});