app.controller('BaseProcessController',function ($scope,BaseProcessService) {


    /**
     * 工序模块
     * @author guolin
     */


    /**
     * 选中工序ID集合
     * @type {Array}
     */
    $scope.processSelectedIds = [];

    /**
     * 当前工序实体
     * @type {{}}
     */
    $scope.process = {};

    /**
     * 更新ID集合
     * @param $event
     * @param id
     */
    $scope.processUpdateSelection = function($event, id) {
        if($event.target.checked){//如果是被选中,则增加到数组
            $scope.processSelectedIds.push( id);
        }else{
            var idx = $scope.processSelectedIds.indexOf(id);
            $scope.processSelectedIds.splice(idx, 1);//删除
        }
    }

    /**
     * 加载所有工序
     */
    $scope.getAllProcess = function(){
        BaseProcessService.getAll().success((response)=>{
            if (response.code == 200){
                $scope.processList = response.data;
            } else{
                requestError(response.msg)
            }
        }).error((e)=>{systemError()})
    }

    /**
     * 根据id查找
     * @param id
     */
    $scope.findone = function(id){
        BaseProcessService.findone(id).success((response)=>{
            if (response.code == 200){
                $scope.process = response.data
            } else{
                requestError(response.msg)
            }
        }).error((e)=>{systemError()})
    }

    /**
     * 保存工序编辑
     */
    $scope.processSave = function(){
        if($scope.process.id==null){
            //新增
            BaseProcessService.add($scope.process).success((response)=>{
                if (response.code == 200){
                    $scope.getAllProcess()
                    saveSuccess()
                } else{
                    requestError(response.msg)
                }
            }).error((e)=>{systemError()})
        }else{
            //修改
            BaseProcessService.update($scope.process).success((response)=>{
                if (response.code == 200){
                    $scope.getAllProcess()
                    updateSuccess()
                } else{
                    requestError(response.msg)
                }
            }).error((e)=>{systemError()})
        }
    }

    /**
     * 删除工序
     * @type {*[]}
     */
    $scope.delete = function(id){
        layer.confirm('您确定要删除吗？', {
            btn: ['确定','取消'] //按钮
        }, function(){
            BaseProcessService.delete(id).success((response)=>{
                if (response.code == 200){
                    $scope.getAllProcess()
                    deleteSuccess()
                } else{
                    requestError(response.msg)
                }
            }).error((e)=>{systemError()})
        })
    }

    /**
     * 批量删除
     * @type {*[]}
     */
    $scope.batchDelete = function(){
        layer.confirm('您确定要删除吗？', {
            btn: ['确定','取消'] //按钮
        }, function(){
            if($scope.processSelectedIds.length==0){
                primaryMessage('请选择')
            }else{
                BaseProcessService.deleteBatch($scope.processSelectedIds).success((response)=>{
                    if (response.code == 200){
                        $scope.getAllProcess()
                        deleteSuccess()
                    } else{
                        requestError(response.msg)
                    }
                }).error((e)=>{systemError()})

            }
        })
    }







    $scope.processList = [
        {
            "id":1,
            "way":"火焰下料",
            "order":1
        },
        {
            "id":2,
            "way":"锯床下料",
            "order":2
        },
        {
            "id":3,
            "way":"减板下料",
            "order":3
        },
        {
            "id":4,
            "way":"焊接",
            "order":4
        },
        {
            "id":5,
            "way":"车床",
            "order":5
        },
        {
            "id":6,
            "way":"铣床",
            "order":6
        }
    ]

});